
## @knitr setup, include=FALSE
# smaller font size for chunks
opts_chunk$set(size = 'scriptsize')
purl("trendPVA.Rnw") ## Dump all R code to a file


